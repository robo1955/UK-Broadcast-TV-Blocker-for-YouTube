package com.ukbb.youtubeblocker

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.ukbb.youtubeblocker.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val prefs by lazy {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
    }

    private var blockingEnabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, true)
        set(value) {
            prefs.edit().putBoolean(KEY_ENABLED, value).apply()
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.blockingSwitch.isChecked = blockingEnabled
        binding.blockingSwitch.setOnCheckedChangeListener { _, isChecked ->
            blockingEnabled = isChecked
            applyBlockingState(isChecked)
        }

        configureWebView()
        registerDocumentStartScripts()
        loadYouTube(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        loadYouTube(intent)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        binding.youtubeWebView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            userAgentString = MOBILE_USER_AGENT
        }

        binding.youtubeWebView.addJavascriptInterface(AndroidBridge(), BRIDGE_NAME)
        binding.youtubeWebView.webChromeClient = WebChromeClient()

        binding.youtubeWebView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val url = request.url.toString()
                return if (isYouTubeUrl(url)) {
                    false
                } else {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                    true
                }
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                binding.loadingIndicator.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                binding.loadingIndicator.visibility = View.GONE
                injectRuntimeScripts()
                applyBlockingState(blockingEnabled)
            }
        }
    }

    private fun registerDocumentStartScripts() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            return
        }

        val script = buildInjectionScript(includeStyles = true)
        WebViewCompat.addDocumentStartJavaScript(
            binding.youtubeWebView,
            script,
            setOf("*://*.youtube.com/*", "*://youtube.com/*", "*://m.youtube.com/*")
        )
    }

    private fun injectRuntimeScripts() {
        val currentUrl = binding.youtubeWebView.url ?: return
        if (!isYouTubeUrl(currentUrl)) return

        val script = buildInjectionScript(includeStyles = !hasDocumentStartSupport())
        binding.youtubeWebView.evaluateJavascript(script, null)
    }

    private fun hasDocumentStartSupport(): Boolean {
        return WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
    }

    private fun buildInjectionScript(includeStyles: Boolean): String {
        val blocklist = readAsset("blocklist.js")
        val content = readAsset("content-android.js")
        val styles = if (includeStyles) readAsset("styles.css") else ""

        val styleInjection = if (styles.isNotBlank()) {
            """
            (function() {
              if (document.getElementById('ukbb-style')) return;
              const style = document.createElement('style');
              style.id = 'ukbb-style';
              style.textContent = ${jsonString(styles)};
              (document.head || document.documentElement).appendChild(style);
            })();
            """.trimIndent()
        } else {
            ""
        }

        return listOf(styleInjection, blocklist, content)
            .filter { it.isNotBlank() }
            .joinToString("\n")
    }

    private fun applyBlockingState(enabled: Boolean) {
        binding.youtubeWebView.evaluateJavascript(
            "window.ukbbSetEnabled && window.ukbbSetEnabled($enabled);",
            null
        )
    }

    private fun loadYouTube(intent: Intent?) {
        val target = intent?.data?.toString() ?: DEFAULT_YOUTUBE_URL
        val url = if (isYouTubeUrl(target)) target else DEFAULT_YOUTUBE_URL
        if (binding.youtubeWebView.url != url) {
            binding.youtubeWebView.loadUrl(url)
        }
    }

    private fun isYouTubeUrl(url: String): Boolean {
        return url.contains("youtube.com")
    }

    private fun readAsset(fileName: String): String {
        return assets.open(fileName).bufferedReader().use { it.readText() }
    }

    private fun jsonString(value: String): String {
        val escaped = value
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "")
        return "\"$escaped\""
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun isBlockingEnabled(): Boolean = blockingEnabled
    }

    companion object {
        private const val PREFS_NAME = "uk_broadcaster_blocker"
        private const val KEY_ENABLED = "blocking_enabled"
        private const val BRIDGE_NAME = "UKBBAndroid"
        private const val DEFAULT_YOUTUBE_URL = "https://m.youtube.com/"
        private const val MOBILE_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    }
}