# UK Broadcaster Blocker for Android

Android version of the Chrome extension that blocks BBC, Channel 4, ITV, and Channel 5 content on YouTube.

## What you get

This folder contains a native Android app that opens YouTube in a built-in browser and injects the same blocking logic used by the Chrome extension.

## Build the APK

1. Install [Android Studio](https://developer.android.com/studio).
2. Open this folder as a project.
3. Let Gradle sync, then run **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install the APK from `app/build/outputs/apk/debug/app-debug.apk`.

### Install on a phone or emulator

```text
adb install app/build/outputs/apk/debug/app-debug.apk
```

## How to use

1. Open **UK Broadcaster Blocker** on your Android device.
2. YouTube mobile loads inside the app.
3. Use the **Blocking** switch in the toolbar to turn filtering on or off.

Blocked videos show the same overlay used by the desktop extension. Watch pages from blocked broadcasters are stopped and replaced with a blocked message.

## Important note about the official YouTube app

This tool works in a browser context, like the Chrome extension. It does not modify the separate YouTube app from Google Play. Use this app (or the browser options below) when you want broadcaster filtering on Android.

## Other Android options

- **Firefox + Violentmonkey:** install `youtube-uk-broadcaster-blocker.user.js` from the parent folder.
- **Kiwi Browser:** load the unpacked Chrome extension from `youtube-uk-broadcaster-blocker`.