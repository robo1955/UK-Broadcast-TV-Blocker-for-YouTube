# Keep the JavaScript bridge available to injected scripts.
-keepclassmembers class com.ukbb.youtubeblocker.MainActivity$AndroidBridge {
    public *;
}