// UK broadcaster blocklist — channel IDs, handles, and name patterns.

const UK_BROADCASTER_BLOCKLIST = (() => {
  const CHANNEL_IDS = new Set([
    // BBC
    "UCCj956IF62FbT7Gouszaj9w",
    "UC16niRr50-MSBwiO3YDb3RA",
    "UCW6-BQWFA70Dyyc7ZpZ9Xlg",
    "UCX8CWR8XKh3IBexw8zvId8Q",
    "UC_qs3c0ehDvZkbiEbOj6Drg",
    "UCoA7dPX0YqLScn7gZf-1T4w",
    "UC0pMmemsHZuc_Sb67EMpuVA",
    "UCASzMjz_Jkved0fjMgthZHA",
    "UC7FWeF-CBe-y6cY4r2eTs9A",
    "UC8p-9tAS1BjEK-ESs1aHXcg",

    // Channel 4
    "UC9uD-X5gtQ1a52Yn0jHZMQ",
    "UCzGBWlwAw7KpW5A7m1xLJzw",
    "UC6H07z6zAwbHRt4mARJLwYg",

    // ITV
    "UCoEqHpK5VNVEBRvwL0EW8Gw",
    "UC7IMX6g8qFy3xHmiJ0xeq8g",

    // Channel 5
    "UC1XSYJz0tzqNONTlIoRpqog",
    "UC-AQKm7HUNMmxjdS371MSwg",
    "UCrRttZIypNTA1Mrfwo745Sg"
  ]);

  const HANDLES = new Set([
    "bbc",
    "bbciplayer",
    "bbcnews",
    "bbcsport",
    "bbcearth",
    "bbcthree",
    "bbcradio1",
    "bbclearningenglish",
    "bbcworldservice",
    "bbcarchive",
    "bbcmusic",
    "channel4",
    "channel4news",
    "channel4entertainment",
    "itv",
    "itvnews",
    "itv2",
    "itvbe",
    "itvcatchup",
    "channel5",
    "5newsuk",
    "5action",
    "5action2026",
    "5star"
  ]);

  const NAME_PATTERNS = [
    /^BBC\b/i,
    /^BBC\s/i,
    /\bBBC\s(?:News|Sport|Earth|Three|Archive|Music|Radio|iPlayer|World Service|Learning English)\b/i,
    /^Channel\s*4\b/i,
    /^Channel\s*4\s/i,
    /\bChannel\s*4\s(?:News|Entertainment)\b/i,
    /^ITV\b/i,
    /^ITV\s/i,
    /\bITV\s(?:News|2|Be)\b/i
  ];

  const URL_PATTERNS = [
    /\/channel\/(UC[\w-]{22})\b/i,
    /\/@([\w.-]+)\b/i,
    /\/user\/([\w.-]+)\b/i,
    /\/c\/([\w.-]+)\b/i
  ];

  function normalizeHandle(handle) {
    return handle.replace(/^@/, "").toLowerCase();
  }

  function isBlockedChannelId(id) {
    return id ? CHANNEL_IDS.has(id) : false;
  }

  function isBlockedHandle(handle) {
    if (!handle) return false;
    const normalized = normalizeHandle(handle);
    if (HANDLES.has(normalized)) return true;
    for (const blocked of HANDLES) {
      if (normalized.startsWith(blocked + "_")) {
        return true;
      }
    }
    return false;
  }

  function isBlockedName(name) {
    if (!name) return false;
    return NAME_PATTERNS.some((pattern) => pattern.test(name.trim()));
  }

  function extractFromUrl(url) {
    if (!url) return { channelId: null, handle: null };
    let channelId = null;
    let handle = null;
    for (const pattern of URL_PATTERNS) {
      const match = url.match(pattern);
      if (!match) continue;
      if (pattern.source.includes("UC")) {
        channelId = match[1];
      } else {
        handle = normalizeHandle(match[1]);
      }
    }
    return { channelId, handle };
  }

  function isBlocked({ channelId, handle, channelName, url } = {}) {
    if (channelId && isBlockedChannelId(channelId)) return true;
    if (handle && isBlockedHandle(handle)) return true;
    if (channelName && isBlockedName(channelName)) return true;
    if (url) {
      const extracted = extractFromUrl(url);
      if (extracted.channelId && isBlockedChannelId(extracted.channelId)) return true;
      if (extracted.handle && isBlockedHandle(extracted.handle)) return true;
    }
    return false;
  }

  return {
    CHANNEL_IDS,
    HANDLES,
    NAME_PATTERNS,
    isBlocked,
    isBlockedChannelId,
    isBlockedHandle,
    isBlockedName,
    extractFromUrl,
    normalizeHandle
  };
})();