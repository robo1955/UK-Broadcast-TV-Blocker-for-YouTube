(() => {
  "use strict";

  const BLOCKED_ATTR = "data-ukbb-blocked";
  const PROCESSED_ATTR = "data-ukbb-processed";
  const PLACEHOLDER_CLASS = "ukbb-placeholder";

  const VIDEO_SELECTORS = [
    "ytd-video-renderer",
    "ytd-grid-video-renderer",
    "ytd-rich-item-renderer",
    "ytd-compact-video-renderer",
    "ytd-playlist-video-renderer",
    "ytd-reel-item-renderer",
    "ytm-video-with-context-renderer",
    "ytm-compact-video-renderer"
  ].join(",");

  const CHANNEL_LINK_SELECTORS = [
    "a[href*='/channel/']",
    "a[href*='/@']",
    "a[href*='/user/']",
    "a[href*='/c/']"
  ].join(",");

  let enabled = true;
  let observer = null;
  let scanScheduled = false;

  function isEnabled() {
    return enabled;
  }

  function scheduleScan() {
    if (!enabled || scanScheduled) return;
    scanScheduled = true;
    requestAnimationFrame(() => {
      scanScheduled = false;
      scanPage();
    });
  }

  function getChannelLinks(root) {
    return Array.from(root.querySelectorAll(CHANNEL_LINK_SELECTORS));
  }

  function getChannelNameFromElement(root) {
    const nameEl =
      root.querySelector("ytd-channel-name #text") ||
      root.querySelector("ytd-channel-name a") ||
      root.querySelector("#channel-name a") ||
      root.querySelector("#metadata-line a") ||
      root.querySelector("yt-formatted-string.ytd-channel-name");
    return nameEl?.textContent?.trim() || null;
  }

  function evaluateChannel({ channelId, handle, channelName, url }) {
    return UK_BROADCASTER_BLOCKLIST.isBlocked({
      channelId,
      handle,
      channelName,
      url
    });
  }

  function evaluateFromLink(link) {
    const href = link.getAttribute("href") || "";
    const { channelId, handle } = UK_BROADCASTER_BLOCKLIST.extractFromUrl(href);
    const channelName = link.textContent?.trim() || null;
    return evaluateChannel({ channelId, handle, channelName, url: href });
  }

  function blockElement(el, label) {
    if (el.getAttribute(BLOCKED_ATTR) === "true") return;
    el.setAttribute(BLOCKED_ATTR, "true");
    el.classList.add("ukbb-blocked");

    if (!el.querySelector(`.${PLACEHOLDER_CLASS}`)) {
      const placeholder = document.createElement("div");
      placeholder.className = PLACEHOLDER_CLASS;
      placeholder.setAttribute("role", "status");
      placeholder.innerHTML = `
        <div class="ukbb-placeholder-inner">
          <span class="ukbb-placeholder-icon" aria-hidden="true">🚫</span>
          <p class="ukbb-placeholder-title">Blocked broadcaster content</p>
          <p class="ukbb-placeholder-sub">${label || "BBC, Channel 4, ITV, or Channel 5"} content hidden by UK Broadcaster Blocker.</p>
        </div>
      `;
      el.appendChild(placeholder);
    }
  }

  function unblockElement(el) {
    el.removeAttribute(BLOCKED_ATTR);
    el.classList.remove("ukbb-blocked");
    el.querySelectorAll(`.${PLACEHOLDER_CLASS}`).forEach((node) => node.remove());
  }

  function scanVideoCard(card) {
    if (card.getAttribute(PROCESSED_ATTR) === "scanning") return;
    card.setAttribute(PROCESSED_ATTR, "scanning");

    const links = getChannelLinks(card);
    let blocked = false;
    let label = null;

    for (const link of links) {
      if (evaluateFromLink(link)) {
        blocked = true;
        label = link.textContent?.trim() || null;
        break;
      }
    }

    if (!blocked) {
      const channelName = getChannelNameFromElement(card);
      if (channelName && UK_BROADCASTER_BLOCKLIST.isBlockedName(channelName)) {
        blocked = true;
        label = channelName;
      }
    }

    if (blocked && enabled) {
      blockElement(card, label);
    } else if (!blocked) {
      unblockElement(card);
    }

    card.setAttribute(PROCESSED_ATTR, "done");
  }

  function scanVideoCards() {
    document.querySelectorAll(VIDEO_SELECTORS).forEach(scanVideoCard);
  }

  function getWatchPageChannelInfo() {
    const response = window.ytInitialPlayerResponse;
    if (response?.videoDetails) {
      const channelId = response.videoDetails.channelId || null;
      const channelName =
        response.videoDetails.author ||
        response.microformat?.playerMicroformatRenderer?.ownerChannelName ||
        null;
      if (channelId || channelName) {
        return { channelId, channelName, handle: null, url: null };
      }
    }

    const ownerLink =
      document.querySelector("ytd-watch-metadata ytd-channel-name a") ||
      document.querySelector("#owner ytd-channel-name a") ||
      document.querySelector("ytm-owner ytd-channel-name a");

    if (ownerLink) {
      const href = ownerLink.getAttribute("href") || "";
      const { channelId, handle } = UK_BROADCASTER_BLOCKLIST.extractFromUrl(href);
      return {
        channelId,
        handle,
        channelName: ownerLink.textContent?.trim() || null,
        url: href
      };
    }

    return null;
  }

  function blockWatchPage() {
    const info = getWatchPageChannelInfo();
    if (!info) return false;

    if (!evaluateChannel(info)) return false;

    const player =
      document.querySelector("#movie_player") ||
      document.querySelector("ytd-watch-flexy") ||
      document.querySelector("#player-container-id");

    const target = player || document.querySelector("ytd-page-manager");
    if (!target || target.getAttribute(BLOCKED_ATTR) === "true") return true;

    blockElement(
      target,
      info.channelName || "BBC / Channel 4 / ITV / Channel 5"
    );

    // Stop playback if already started
    const video = document.querySelector("video");
    if (video) {
      video.pause();
      video.removeAttribute("src");
      video.load();
    }

    document.title = "Blocked — UK Broadcaster Blocker";
    return true;
  }

  function scanChannelPage() {
    const path = location.pathname;
    const isChannelPath =
      path.startsWith("/@") ||
      path.startsWith("/channel/") ||
      path.startsWith("/user/") ||
      path.startsWith("/c/");

    if (!isChannelPath) return;

    const { channelId, handle } = UK_BROADCASTER_BLOCKLIST.extractFromUrl(path);
    const headerName =
      document.querySelector("yt-dynamic-text-view-model h1")?.textContent?.trim() ||
      document.querySelector("#channel-header-container #text")?.textContent?.trim() ||
      document.querySelector("yt-formatted-string.ytd-channel-name")?.textContent?.trim() ||
      null;

    if (
      evaluateChannel({
        channelId,
        handle,
        channelName: headerName,
        url: path
      })
    ) {
      const page = document.querySelector("ytd-browse") || document.body;
      blockElement(page, headerName || handle || "Blocked channel");
    }
  }

  function scanPage() {
    if (!enabled) return;
    scanVideoCards();
    if (location.pathname === "/watch") {
      blockWatchPage();
    }
    scanChannelPage();
  }

  function setEnabled(value) {
    enabled = value;
    if (!enabled) {
      document
        .querySelectorAll(`[${BLOCKED_ATTR}="true"]`)
        .forEach(unblockElement);
      document
        .querySelectorAll(`[${PROCESSED_ATTR}]`)
        .forEach((el) => el.removeAttribute(PROCESSED_ATTR));
      return;
    }
    document
      .querySelectorAll(`[${PROCESSED_ATTR}]`)
      .forEach((el) => el.removeAttribute(PROCESSED_ATTR));
    scheduleScan();
  }

  function startObserver() {
    if (observer) return;
    observer = new MutationObserver(() => scheduleScan());
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }

  function init() {
    chrome.storage.sync.get({ enabled: true }, (result) => {
      enabled = result.enabled;
      startObserver();
      scheduleScan();

      if (location.pathname === "/watch") {
        const poll = setInterval(() => {
          if (!enabled) {
            clearInterval(poll);
            return;
          }
          if (blockWatchPage()) {
            clearInterval(poll);
          }
        }, 500);
        setTimeout(() => clearInterval(poll), 15000);
      }
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "sync" || !changes.enabled) return;
      setEnabled(changes.enabled.newValue);
    });

    chrome.runtime.onMessage.addListener((message) => {
      if (message?.type === "SET_ENABLED") {
        setEnabled(message.enabled);
      }
    });

    window.addEventListener("yt-navigate-finish", () => {
      document
        .querySelectorAll(`[${PROCESSED_ATTR}]`)
        .forEach((el) => el.removeAttribute(PROCESSED_ATTR));
      scheduleScan();
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();