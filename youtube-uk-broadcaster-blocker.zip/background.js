chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get({ enabled: true }, (result) => {
    if (result.enabled === undefined) {
      chrome.storage.sync.set({ enabled: true });
    }
  });
});

chrome.action.onClicked.addListener(() => {
  // Popup handles UI; this is a fallback no-op.
});