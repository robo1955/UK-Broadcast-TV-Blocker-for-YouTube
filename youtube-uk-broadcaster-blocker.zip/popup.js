const toggle = document.getElementById("enabledToggle");
const statusText = document.getElementById("statusText");

chrome.storage.sync.get({ enabled: true }, (result) => {
  toggle.checked = result.enabled;
  updateStatus(result.enabled);
});

toggle.addEventListener("change", () => {
  const enabled = toggle.checked;
  chrome.storage.sync.set({ enabled }, () => {
    updateStatus(enabled);

    chrome.tabs.query({ url: "*://*.youtube.com/*" }, (tabs) => {
      for (const tab of tabs) {
        chrome.tabs.sendMessage(tab.id, { type: "SET_ENABLED", enabled }).catch(() => {});
      }
    });
  });
});

function updateStatus(enabled) {
  if (enabled) {
    statusText.textContent = "Active on YouTube";
    statusText.classList.add("active");
  } else {
    statusText.textContent = "Paused — content is visible";
    statusText.classList.remove("active");
  }
}